# 开发环境配置



```
IP: 10.63.14.213

# MySql
port: 53306
user/pwd: root/root1234

redis: 56379



```







## MySQL

```

# mysql 
docker run -d --name dev-mysql  -p 53306:3306 -v /home/user/data/mysql/dev/conf:/etc/mysql/conf.d -v /home/user/data/mysql/dev/data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root1234 -d mysql:5.7


# database

CREATE DATABASE IF NOT EXISTS webasenodemanager DEFAULT CHARSET utf8 COLLATE utf8_general_ci;


```



## Redis

```
docker run --restart=always -p 56379:6379 --name dev-redis --privileged=true -v /home/redis/conf/redis.conf:/etc/redis/redis.conf -v /home/redis/data:/data -d redis


docker run --restart=always -p 56379:6379 --name dev-redis --privileged=true  -v /home/user/data/redis/data:/data -d redis:7.2

```





##  容器批量删除

```
docker rm `docker ps -a | awk 'NR>1 {print $1}'`
```







